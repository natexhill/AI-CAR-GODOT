extends CharacterBody2D

@onready var rayr = $Right
@onready var rayl = $Left
@onready var Speed_Label = $speed_label

var speed = 100.0
var max_speed = 200
var min_speed = 50

var current_box = 0
var current_box_s = 0
var choice = ""
var choice_s = ""

var matchbox1 = ["R","L"]
var matchbox2 = ["R","L"]
var matchbox3 = ["R","L"]
var matchbox4 = ["R","L"]
var matchbox1_s = ["A","B"]
var matchbox2_s = ["A","B"]
var matchbox3_s = ["A","B"]
var matchbox4_s = ["A","B"]

func _physics_process(delta: float) -> void:
	# assign matchbox
	if not rayr.is_colliding() and not rayl.is_colliding():
		current_box = 1
		current_box_s = 1
	elif rayr.is_colliding() and not rayl.is_colliding():
		current_box = 2
		current_box_s = 2
	elif not rayr.is_colliding() and rayl.is_colliding():
		current_box = 3
		current_box_s = 3
	elif rayr.is_colliding() and rayl.is_colliding():
		current_box = 4
		current_box_s = 4

	#pick choice 
	if current_box == 1:
		choice = matchbox1.pick_random()
	elif current_box == 2:
		choice = matchbox2.pick_random()
	elif current_box == 3:
		choice = matchbox3.pick_random()
	elif current_box == 4:
		choice = matchbox4.pick_random()
		
	if current_box_s == 1:
		choice_s = matchbox1_s.pick_random()
	elif current_box_s == 2:
		choice_s = matchbox2_s.pick_random()
	elif current_box_s == 3:
		choice_s = matchbox3_s.pick_random()
	elif current_box_s == 4:
		choice_s = matchbox4_s.pick_random()

	#controls
	if choice == "R":
		rotation_degrees += 10.0
		speed -= 0.1
	elif choice == "L":
		rotation_degrees -= 10.0
		speed -= 0.1
		
	if choice_s == "A":
		if speed < max_speed:
			speed += 0.5
	elif choice_s == "B": 
			if speed > min_speed:
				speed -= 0.1
	velocity = Vector2(speed, 0).rotated(rotation)
	move_and_slide()

	if is_on_wall() or is_on_floor() or is_on_ceiling():
		if current_box == 1 and matchbox1.size() > 1:
			matchbox1.erase(choice)
		elif current_box == 2 and matchbox2.size() > 1:
			matchbox2.erase(choice)
		elif current_box == 3 and matchbox3.size() > 1:
			matchbox3.erase(choice)
		elif current_box == 4 and matchbox4.size() > 1:
			matchbox4.erase(choice)
			
		if current_box_s == 1 and matchbox1_s.size() > 1:
			matchbox1_s.erase(choice_s)
		elif current_box_s == 2 and matchbox2_s.size() > 1:
			matchbox2_s.erase(choice_s)
		elif current_box_s == 3 and matchbox3_s.size() > 1:
			matchbox3_s.erase(choice_s)
		elif current_box_s == 4 and matchbox4_s.size() > 1:
			matchbox4_s.erase(choice_s)
		global_position = Vector2(232,48)
		rotation_degrees = 0.0
		speed = 100
		
