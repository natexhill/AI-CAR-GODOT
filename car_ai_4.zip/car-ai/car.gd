extends CharacterBody2D

@onready var rayr = $Right
@onready var rayl = $Left
@onready var rays = $Straight

var speed = 100
var max_speed = 200
var min_speed = 50

var current_box = 0
var current_box_s = 0
var choice = ""
var choice_s = ""

var matchbox1 = ["R","L","Rs","Ls"]
var matchbox2 = ["R","L","Rs","Ls"]
var matchbox3 = ["R","L","Rs","Ls"]
var matchbox4 = ["R","L","Rs","Ls"]
var matchbox5 = ["R","L","Rs","Ls"]
var matchbox6 = ["R","L","Rs","Ls"]
var matchbox7 = ["R","L","Rs","Ls"]
var matchbox8 = ["R","L","Rs","Ls"]

var matchbox1_s = ["A","N"]
var matchbox2_s = ["A","N"]
var matchbox3_s = ["A","N"]
var matchbox4_s = ["A","N"]
var matchbox5_s = ["A","N"]
var matchbox6_s = ["A","N"]
var matchbox7_s = ["A","N"]
var matchbox8_s = ["A","N"]

func _physics_process(delta: float) -> void:
	# Get collision states as integers (0 or 1)
	var l = int(rayl.is_colliding())
	var m = int(rays.is_colliding())
	var r = int(rayr.is_colliding())

	# Calculate the unique box number (1 to 8) using 3-bit binary
	current_box = (l * 4) + (m * 2) + r + 1
	current_box_s = current_box


	#pick choice 
	if current_box == 1:
		choice = matchbox1.pick_random()
	elif current_box == 2:
		choice = matchbox2.pick_random()
	elif current_box == 3:
		choice = matchbox3.pick_random()
	elif current_box == 4:
		choice = matchbox4.pick_random()
	elif current_box == 5:
		choice = matchbox5.pick_random()
	elif current_box == 6:
		choice = matchbox6.pick_random()
	elif current_box == 7:
		choice = matchbox7.pick_random()
	elif current_box == 8:
		choice = matchbox8.pick_random()
	
	if current_box_s == 1:
		choice_s = matchbox1_s.pick_random()
	elif current_box_s == 2:
		choice_s = matchbox2_s.pick_random()
	elif current_box_s == 3:
		choice_s = matchbox3_s.pick_random()
	elif current_box_s == 4:
		choice_s = matchbox4_s.pick_random()
	elif current_box_s == 5:
		choice_s = matchbox5_s.pick_random()
	elif current_box_s == 6:
		choice_s = matchbox6_s.pick_random()
	elif current_box_s == 7:
		choice_s = matchbox7_s.pick_random()
	elif current_box_s == 8:
		choice_s = matchbox8_s.pick_random()

	#controls
	if choice == "R":
		rotation_degrees += 10.0
		#speed -= 0.5
	elif choice == "L":
		rotation_degrees -= 10.0
		#speed -= 0.5
	elif choice == "Rs":
		rotation_degrees += 5.0
		#speed -= 0.2
	elif choice == "Ls":
		rotation_degrees -= 5.0
		#speed -= 0.2
		
	#if choice_s == "A":
		#if speed < max_speed:
			#speed -= 0.5
	velocity = Vector2(speed, 0).rotated(rotation)
	move_and_slide()

	#punishment
	if is_on_wall() or is_on_floor() or is_on_ceiling():
		if current_box == 1 and matchbox1.size() > 1:
			matchbox1.erase(choice)
		elif current_box == 2 and matchbox2.size() > 1:
			matchbox2.erase(choice)
		elif current_box == 3 and matchbox3.size() > 1:
			matchbox3.erase(choice)
		elif current_box == 4 and matchbox4.size() > 1:
			matchbox4.erase(choice)
		elif current_box == 5 and matchbox1.size() > 1:
			matchbox5.erase(choice)
		elif current_box == 6 and matchbox2.size() > 1:
			matchbox6.erase(choice)
		elif current_box == 7 and matchbox3.size() > 1:
			matchbox7.erase(choice)
		elif current_box == 8 and matchbox4.size() > 1:
			matchbox8.erase(choice)
			
			
		if current_box_s == 1 and matchbox1_s.size() > 1:
			matchbox1_s.erase(choice_s)
		elif current_box_s == 2 and matchbox2_s.size() > 1:
			matchbox2_s.erase(choice_s)
		elif current_box_s == 3 and matchbox3_s.size() > 1:
			matchbox3_s.erase(choice_s)
		elif current_box_s == 4 and matchbox4_s.size() > 1:
			matchbox4_s.erase(choice_s)
		elif current_box_s == 5 and matchbox1_s.size() > 1:
			matchbox5_s.erase(choice_s)
		elif current_box_s == 6 and matchbox2_s.size() > 1:
			matchbox6_s.erase(choice_s)
		elif current_box_s == 7 and matchbox3_s.size() > 1:
			matchbox7_s.erase(choice_s)
		elif current_box_s == 8 and matchbox4_s.size() > 1:
			matchbox8_s.erase(choice_s)
		global_position = Vector2(232,48)
		rotation_degrees = 0.0
		speed = 100
		
